#include <iostream>
#include <fstream>
#include <string>
#include <bitset>
using namespace std;

int main(int argc, char *argv[]){
  ifstream f_in;
  ofstream bin, f_out;
  f_in.open(argv[1]);  // hexadecimal instruction file
  bin.open(argv[2]);   // binary instruction file
  f_out.open(argv[3]); // assembly language instruction file

  string line;
  bitset<32> inst;
  bitset<6> opcode;
  bitset<5> rs, rt, rd, shamt;
  bitset<6> funct;
  bitset<16> imm;
  bitset<26> addr;

  while(getline(f_in, line)){
    if(!isalnum(line[0])) continue;
    bitset<4> bin_set[8];
    for(int i = 0; i < 8; i++){
      switch (line[(line.length() - 8 + i >= 0) ? (line.length() - 8 + i) : 0]){
        case '0': bin_set[i] = bitset<4>(0); break;
        case '1': bin_set[i] = bitset<4>(1); break;
        case '2': bin_set[i] = bitset<4>(2); break;
        case '3': bin_set[i] = bitset<4>(3); break;
        case '4': bin_set[i] = bitset<4>(4); break;
        case '5': bin_set[i] = bitset<4>(5); break;
        case '6': bin_set[i] = bitset<4>(6); break;
        case '7': bin_set[i] = bitset<4>(7); break;
        case '8': bin_set[i] = bitset<4>(8); break;
        case '9': bin_set[i] = bitset<4>(9); break;
        case 'a': bin_set[i] = bitset<4>(10); break;
        case 'A': bin_set[i] = bitset<4>(10); break;
        case 'b': bin_set[i] = bitset<4>(11); break;
        case 'B': bin_set[i] = bitset<4>(11); break;
        case 'c': bin_set[i] = bitset<4>(12); break;
        case 'C': bin_set[i] = bitset<4>(12); break;
        case 'd': bin_set[i] = bitset<4>(13); break;
        case 'D': bin_set[i] = bitset<4>(13); break;
        case 'e': bin_set[i] = bitset<4>(14); break;
        case 'E': bin_set[i] = bitset<4>(14); break;
        case 'f': bin_set[i] = bitset<4>(15); break;
        case 'F': bin_set[i] = bitset<4>(15); break;
        default: break;
      }
    }
    inst = bitset<32>(bin_set[0].to_string() + bin_set[1].to_string() + bin_set[2].to_string() + bin_set[3].to_string() + bin_set[4].to_string() + bin_set[5].to_string() + bin_set[6].to_string() + bin_set[7].to_string());
    opcode = bitset<6>(inst.to_string().substr(0, 6));

    bin << inst << endl;

    rs = bitset<5>(inst.to_string().substr(6, 5));
    rt = bitset<5>(inst.to_string().substr(11, 5));
    rd = bitset<5>(inst.to_string().substr(16, 5));
    shamt = bitset<5>(inst.to_string().substr(21, 5));
    funct = bitset<6>(inst.to_string().substr(26, 6));
    imm = bitset<16>(inst.to_string().substr(16, 16));
    addr = bitset<26>(inst.to_string().substr(6, 26));

    if(opcode == bitset<6>(0)){
      if(funct == bitset<6>(0)){
        f_out << "and  " << "$r" << rd.to_ulong() << ", " << "$r" << rs.to_ulong() << ", " << "$r" << rt.to_ulong() << endl;
      }
      else if(funct == bitset<6>(1)){
        f_out << "or   " << "$r" << rd.to_ulong() << ", " << "$r" << rs.to_ulong() << ", " << "$r" << rt.to_ulong() << endl;
      }
      else if(funct == bitset<6>(2)){
        f_out << "add  " << "$r" << rd.to_ulong() << ", " << "$r" << rs.to_ulong() << ", " << "$r" << rt.to_ulong() << endl;
      }
      else if(funct == bitset<6>(3)){
        f_out << "sub  " << "$r" << rd.to_ulong() << ", " << "$r" << rs.to_ulong() << ", " << "$r" << rt.to_ulong() << endl;
      }
      else if(funct == bitset<6>(4)){
        f_out << "slt  " << "$r" << rd.to_ulong() << ", " << "$r" << rs.to_ulong() << ", " << "$r" << rt.to_ulong() << endl;
      }
      else if(funct == bitset<6>(5)){
        f_out << "sll  " << "$r" << rd.to_ulong() << ", " << "$r" << rt.to_ulong() << ", " << shamt.to_ulong() << endl;
      }
      else if(funct == bitset<6>(6)){
        f_out << "nor  " << "$r" << rd.to_ulong() << ", " << "$r" << rs.to_ulong() << ", " << "$r" << rt.to_ulong() << endl;
      }
      else if(funct == bitset<6>(7)){
        f_out << "jr   " << "$r" << rs.to_ulong() << endl;
      }
    }
    else if(opcode == bitset<6>(1)){
      f_out << "andi " << "$r" << rt.to_ulong() << ", " << "$r" << rs.to_ulong() << ", " << imm.to_ulong() << endl;
    }
    else if(opcode == bitset<6>(2)){
      f_out << "ori  " << "$r" << rt.to_ulong() << ", " << "$r" << rs.to_ulong() << ", " << imm.to_ulong() << endl;
    }
    else if(opcode == bitset<6>(3)){
      int imm_int;
      if(imm[15] == 1)
        imm_int = imm.to_ulong() - 65536;
      else
        imm_int = imm.to_ulong();
      f_out << "addi " << "$r" << rt.to_ulong() << ", " << "$r" << rs.to_ulong() << ", " << imm_int << endl;
    }
    else if(opcode == bitset<6>(4)){
      int imm_int;
      if(imm[15] == 1)
        imm_int = imm.to_ulong() - 65536;
      else
        imm_int = imm.to_ulong();
      f_out << "subi " << "$r" << rt.to_ulong() << ", " << "$r" << rs.to_ulong() << ", " << imm_int << endl;
    }
    else if(opcode == bitset<6>(5)){
      f_out << "lw   " << "$r" << rt.to_ulong() << ", " << imm.to_ulong() << "(" << "$r" << rs.to_ulong() << ")" << endl;
    }
    else if(opcode == bitset<6>(6)){
      f_out << "sw   " << "$r" << rt.to_ulong() << ", " << imm.to_ulong() << "(" << "$r" << rs.to_ulong() << ")" << endl;
    }
    else if(opcode == bitset<6>(7)){
      int imm_int;
      if(imm[15] == 1)
        imm_int = imm.to_ulong() - 65536;
      else
        imm_int = imm.to_ulong();
      f_out << "beq  " << "$r" << rs.to_ulong() << ", " << "$r" << rt.to_ulong() << ", " << imm_int << endl;
    }
    else if(opcode == bitset<6>(8)){
      int imm_int;
      if(imm[15] == 1)
        imm_int = imm.to_ulong() - 65536;
      else
        imm_int = imm.to_ulong();
      f_out << "bne  " << "$r" << rs.to_ulong() << ", " << "$r" << rt.to_ulong() << ", " << imm_int << endl;
    }
    else if(opcode == bitset<6>(9)){
      f_out << "lui  " << "$r" << rt.to_ulong() << ", " << imm.to_ulong() << endl;
    }
    else if(opcode == bitset<6>(10)){
      f_out << "j    " << addr.to_ulong() << endl;
    }
    else if(opcode == bitset<6>(11)){
      f_out << "jal  " << addr.to_ulong() << endl;
    }
  }

  f_in.close();
  bin.close();
  f_out.close();
  return EXIT_SUCCESS;
}